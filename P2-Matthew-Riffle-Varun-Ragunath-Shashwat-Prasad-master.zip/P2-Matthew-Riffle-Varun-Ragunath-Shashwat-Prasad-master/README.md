# P2-Matthew-Riffle-Varun-Ragunath-Shashwat-Prasad

## System Requirements
- PHP
- MacOS or Windows
- MySQL

## How to Use
Navigate to the home page in order to draw a sketch, and then save your sketch. This will save the sketch onto the database. From there, use the navigation bar to move from page to page and view all the sketches. You can also search for sketches also.

## Authors
Varun Ragunath, Shashwat Prasad, Matthew Riffle
